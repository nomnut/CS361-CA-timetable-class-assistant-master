package com.example.timetable.timetableview;

public enum HighlightMode {
    COLOR,
    IMAGE
}
